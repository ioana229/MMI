<footer>
    <ul class="footer-list">
        <li><a href="./impressum.php">Impressum</a></li>
        <li><a href="./agb.php">AGB</a></li>
        <li><a href="./datenschutzerklaerung.php">Datenschutzerklärung</a></li>
        <li><a href="./contact.php">Kontakt</a></li>
    </ul>
</footer>
