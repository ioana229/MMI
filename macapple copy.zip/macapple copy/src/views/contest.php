<?php
//Datenbank verbindung herstellen
include '../database/connection.php';
//Start der Session
//Sessions initialisieren wenn noch nicht gemacht
include '../comps/sessioncheck.php';
//Schaue ob der Benuzter eingelogt ist
include '../comps/usercheck.php';
//Datenbank Logik einbinden -- POST Requests an die Datenbank + Backend Logik
include '../database/db_contest.php';
?>

<!-- Frontend & Database Display -->
<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../public/styles/reset.css">
    <link rel="stylesheet" href="../public/styles/index.css">
    <link rel="stylesheet" href="../public/styles/contest.css">
    <link rel="stylesheet" href="../public/styles/partialStyles/header.css">
    <link rel="stylesheet" href="../public/styles/partialStyles/footer.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
        integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="../handlers/rating-handler.js" defer></script>
    <script src="../handlers/btns-view-upload-handlers.js" defer></script>
    <title>Bild hochladen und bewerten</title>
</head>

<body>
    <?php
    // Wenn der Benutzer auf "X" klickt, die Nachricht aus der Session löschen
    if (isset($_GET['close_message'])) {
        unset($_SESSION['success_message']);
        unset($_SESSION['error_message']);
        
        // Verhindert, dass der URL-Parameter in der Adresszeile bleibt
        header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
        exit();
    }
    ?>
    <?php include './partials/header.php'; ?>
    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="success-banner">
            <?php echo $_SESSION['success_message']; ?>
            <a href="?close_message=1" class="close-btn">X</a>
        </div>
    <?php endif; ?>

    <?php if (isset($_SESSION['error_message'])): ?>
        <div class="error-banner">
            <?php echo $_SESSION['error_message']; ?>
            <a href="?close_message=1" class="close-btn">X</a>
        </div>
    <?php endif; ?>

    <main class="main">


        <div class="participate-container">
            <div class="description">Participate in our <span id="funny-dinner-contest">Funny-Dinner-Contest</span>.<br> Share your dinner pics with the community. There's a prize!!<br> Wink Wink </div>
            <div class="button-container">
                <div class="view-your-uploads-container">
                    <button type="button" id="btn-view-your-uploads">VIEW YOUR UPLOADS</button>
                </div>
                <div class="upload-picture-container">
                    <button type="button" id="btn-upload-picture">UPLOAD PICTURE</button>
                </div>
            </div>
        </div>

        <?php
        // Bilder anzeigen und Bewertungsformular bereitstellen
        $sql = "SELECT b.BildID, b.Titel, b.Bilddatei, k.EMail
                FROM Bild b
                JOIN Kunde k ON b.KundenID = k.KundenID
                WHERE b.Freigabestatus = 1";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $emailParts = explode('@', $row['EMail']);
                $username = $emailParts[0];

                // Überprüfen, ob der Benutzer bereits eine Bewertung für dieses Bild abgegeben hat
                $sqlBewertung = "SELECT * FROM Bewertung WHERE BildID = ? AND KundenID = ? AND IstAktiv = 1";
                $stmtBewertung = $conn->prepare($sqlBewertung);
                $stmtBewertung->bind_param("ii", $row['BildID'], $userID);
                $stmtBewertung->execute();
                $resultBewertung = $stmtBewertung->get_result();
                $bereitsBewertet = $resultBewertung->num_rows > 0;

                echo '<div class="uploads-container">
                    <div class="username-title">
                        <h3 class="username">' . htmlspecialchars($username) . '</h3>
                    </div>
                    <div class="upload">
                        <div class="image-container">
                            <img src="' . htmlspecialchars($row['Bilddatei']) . '" alt="' . htmlspecialchars($row['Titel']) . '">
                        </div>
                    </div>
                    <div class="upload-info-container">
                        <div class="image-description-container">
                            <span class="image-description">' . htmlspecialchars($row['Titel']) . '</span>
                        </div>
                        <div class="rating-container">';
                echo '<form method="POST" action="contest.php" class="rating-form">
                                <input type="hidden" name="bild_id" value="' . htmlspecialchars($row['BildID']) . '">
                                <input type="hidden" name="bewerten" value="1">';
                if ($bereitsBewertet) {
                    echo '<button type="submit"><i class="fa-solid fa-heart"></i></button>';
                } else {
                    echo '<button type="submit"><i class="fa-regular fa-heart"></i></button>';
                }
                echo '</form>';
                echo '</div>
                    </div>
                </div>';
            }
        } else {
            echo "Keine Bilder vorhanden.";
        }

        $conn->close();
        ?>

    </main>

    <?php include './partials/footer.php'; ?>

    <script>
        document.querySelectorAll('.rating-form').forEach(form => {
            form.addEventListener('submit', function(e) {
                e.preventDefault();

                const formData = new FormData(this);
                const action = this.getAttribute('action');

                fetch(action, {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        // Handle the response data
                        console.log(data);

                        // Update the button icon based on the response
                        const button = this.querySelector('button');
                        const icon = button.querySelector('i');
                        if (data.status === 'activated') {
                            icon.classList.remove('fa-regular');
                            icon.classList.add('fa-solid');
                        } else {
                            icon.classList.remove('fa-solid');
                            icon.classList.add('fa-regular');
                        }
                    })
                    .catch(error => console.error('Error:', error));
            });
        });
    </script>

</body>
</html>

<style>
/* Erfolgsmeldung-Banner */
.success-banner {
    width: 100%;
    background-color: #4CAF50; /* Grüner Hintergrund für Erfolg */
    color: white;
    text-align: center;
    padding: 5px;
    font-size: 16px;
    font-weight: bold;
    position: relative;
    margin-top: 0px;
}

/* Fehlermeldung-Banner */
.error-banner {
    width: 100%;
    background-color: #FF5733; /* Roter Hintergrund für Fehler */
    color: white;
    text-align: center;
    padding: 5px;
    font-size: 16px;
    font-weight: bold;
    position: relative;
    margin-top: 0px;
    
}
/* Close Button */
.close-btn {
    position: absolute;
    top: 50%;
    right: 5px; /* Keep it 5px from the right */
    transform: translateY(-50%); /* Center vertically */
    text-decoration: none;
    color: white;
    font-size: 18px;
    font-weight: bold;
    padding: 5px;
    cursor: pointer;
}

</style>
