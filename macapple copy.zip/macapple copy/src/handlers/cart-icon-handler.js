const cartIcon = document.querySelector(".cart-icon");

cartIcon.addEventListener("click", () => {
    window.location.href = './warenkorb.php';
});
